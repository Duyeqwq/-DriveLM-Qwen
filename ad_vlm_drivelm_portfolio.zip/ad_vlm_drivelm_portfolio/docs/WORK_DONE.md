# 项目工作说明：DriveLM × Qwen2.5-VL 自动驾驶 VQA 微调

基于 Qwen2.5-VL 与 DriveLM-nuScenes，搭建自动驾驶视觉问答微调链路，完成原始 QA 解析、图文样本构建、训练/评测划分，并将数据适配为 Qwen 指令微调格式。

## 主要工作

1. **数据预处理**
   - DriveLM QA JSON 解析与任务类型统计。
   - 转换为 Qwen-VL SFT / 指令微调格式（单帧）。
   - 按 **scene** 划分 train/eval，避免场景泄漏。

2. **训练**
   - Qwen2.5-VL-7B + LoRA 域适应。
   - 多卡分布式训练，覆盖 perception / prediction / planning 等子任务。

3. **推理与评测**
   - 批量推理与评测脚本：多卡分片、结果合并、子任务指标、错误样本分析。
   - Baseline vs LoRA 对比实验。

## 指标（DriveLM 评测约 1 万条）

| 指标 | 数值 |
|------|------|
| Exact Match | **≈48.5%** |
| Prediction 类任务 Exact Match | **≈66.4%** |

## 目录说明

```text
docs/     README 与工作说明
code/     预处理、划分、推理、评测、错误可视化脚本
configs/  scene 划分清单、LoRA adapter_config
metrics/  baseline / LoRA 评测指标
viz/      错误分析 HTML 样例报告
```

说明：不包含 Qwen 基座权重、LoRA 权重、nuScenes 原始图像与大规模 jsonl 预测文件。
