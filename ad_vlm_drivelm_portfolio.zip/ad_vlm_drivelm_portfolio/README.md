# DriveLM × Qwen2.5-VL 交付包（精简版）

本压缩包仅包含项目说明、关键脚本、评测指标与错误可视化样例，不含模型权重与原始大规模数据。

详见：
- `docs/WORK_DONE.md`：工作与指标
- `docs/README.md`：完整使用说明
- `viz/error_report_eval10k.html`：错误分析可视化样例
