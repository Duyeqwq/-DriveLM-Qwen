#!/usr/bin/env python3
"""Split Qwen-VL JSONL by DriveLM scene to avoid train/eval leakage."""

from __future__ import annotations

import argparse
import json
import random
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

SCENE_RE = re.compile(r"^(scene\d+)_")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def scene_id(row: dict[str, Any]) -> str:
    sample_id = str(row.get("id", ""))
    match = SCENE_RE.match(sample_id)
    if match:
        return match.group(1)
    return "unknown"


def image_exists(row: dict[str, Any]) -> bool:
    for message in row.get("messages", []):
        content = message.get("content", [])
        if not isinstance(content, list):
            continue
        for item in content:
            if isinstance(item, dict) and item.get("type") == "image":
                path = Path(str(item.get("image", "")))
                if path.exists():
                    return True
                return False
    return False


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    scenes = {scene_id(row) for row in rows}
    task_counter: Counter[str] = Counter()
    missing_images = 0
    for row in rows:
        task = str(row.get("metadata", {}).get("task") or "unknown")
        task_counter[task] += 1
        if not image_exists(row):
            missing_images += 1
    return {
        "samples": len(rows),
        "scenes": len(scenes),
        "missing_images": missing_images,
        "by_task": dict(task_counter),
    }


def stratified_subsample(rows: list[dict[str, Any]], max_samples: int, seed: int) -> list[dict[str, Any]]:
    if max_samples <= 0 or len(rows) <= max_samples:
        return rows

    by_task: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        task = str(row.get("metadata", {}).get("task") or "unknown")
        by_task[task].append(row)

    rng = random.Random(seed)
    total = len(rows)
    selected: list[dict[str, Any]] = []
    remaining = max_samples

    tasks = sorted(by_task.keys())
    for idx, task in enumerate(tasks):
        bucket = by_task[task]
        if idx == len(tasks) - 1:
            take = min(remaining, len(bucket))
        else:
            take = min(len(bucket), max(1, round(max_samples * len(bucket) / total)))
            take = min(take, remaining)
        selected.extend(rng.sample(bucket, take) if take < len(bucket) else bucket)
        remaining -= take
        if remaining <= 0:
            break

    rng.shuffle(selected)
    return selected[:max_samples]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path, help="Full converted JSONL.")
    parser.add_argument("--output-dir", required=True, type=Path, help="Directory for split files.")
    parser.add_argument("--eval-ratio", type=float, default=0.1, help="Scene-level eval ratio.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--eval-subset",
        type=int,
        default=10000,
        help="Stratified eval subset size from holdout scenes. Use 0 for full holdout eval.",
    )
    args = parser.parse_args()

    rows = read_jsonl(args.input)
    scenes: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        scenes[scene_id(row)].append(row)

    scene_ids = sorted(scenes.keys())
    rng = random.Random(args.seed)
    rng.shuffle(scene_ids)

    eval_scene_count = max(1, round(len(scene_ids) * args.eval_ratio))
    eval_scenes = set(scene_ids[:eval_scene_count])
    train_scenes = set(scene_ids[eval_scene_count:])

    train_rows: list[dict[str, Any]] = []
    eval_rows: list[dict[str, Any]] = []
    for sid, scene_rows in scenes.items():
        if sid in eval_scenes:
            eval_rows.extend(scene_rows)
        else:
            train_rows.extend(scene_rows)

    eval_subset_rows = stratified_subsample(eval_rows, args.eval_subset, args.seed)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.output_dir / "train.jsonl", train_rows)
    write_jsonl(args.output_dir / "eval_full.jsonl", eval_rows)
    write_jsonl(args.output_dir / "eval.jsonl", eval_subset_rows)

    manifest = {
        "input": str(args.input),
        "seed": args.seed,
        "eval_ratio": args.eval_ratio,
        "train_scenes": sorted(train_scenes),
        "eval_scenes": sorted(eval_scenes),
        "train": summarize(train_rows),
        "eval_full": summarize(eval_rows),
        "eval_subset": summarize(eval_subset_rows),
        "outputs": {
            "train": str(args.output_dir / "train.jsonl"),
            "eval_full": str(args.output_dir / "eval_full.jsonl"),
            "eval": str(args.output_dir / "eval.jsonl"),
        },
    }
    manifest_path = args.output_dir / "split_manifest.json"
    with manifest_path.open("w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
