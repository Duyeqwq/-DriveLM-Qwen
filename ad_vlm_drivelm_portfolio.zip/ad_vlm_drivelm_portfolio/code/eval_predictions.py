#!/usr/bin/env python3
"""Evaluate prediction JSONL with lightweight text metrics."""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def normalize(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\w\s\u4e00-\u9fff]", "", text)
    return text


def score_row(row: dict[str, Any]) -> dict[str, float | bool]:
    answer = normalize(str(row.get("answer", "")))
    prediction = normalize(str(row.get("prediction", "")))
    exact = bool(answer) and answer == prediction
    contains = bool(answer) and (answer in prediction or prediction in answer)
    similarity = SequenceMatcher(None, answer, prediction).ratio() if answer or prediction else 0.0
    return {
        "exact": exact,
        "contains": contains,
        "similarity": similarity,
    }


def aggregate(rows: list[dict[str, Any]]) -> dict[str, Any]:
    scored = [(row, score_row(row)) for row in rows]
    total = len(scored)
    if total == 0:
        return {"total": 0}

    exact = sum(1 for _, score in scored if score["exact"])
    contains = sum(1 for _, score in scored if score["contains"])
    similarity = sum(float(score["similarity"]) for _, score in scored) / total

    by_task: dict[str, list[dict[str, float | bool]]] = defaultdict(list)
    for row, score in scored:
        task = str(row.get("metadata", {}).get("task") or "unknown")
        by_task[task].append(score)

    task_metrics = {}
    for task, scores in by_task.items():
        count = len(scores)
        task_metrics[task] = {
            "total": count,
            "exact_match": sum(1 for score in scores if score["exact"]) / count,
            "contains_match": sum(1 for score in scores if score["contains"]) / count,
            "avg_similarity": sum(float(score["similarity"]) for score in scores) / count,
        }

    return {
        "total": total,
        "exact_match": exact / total,
        "contains_match": contains / total,
        "avg_similarity": similarity,
        "by_task": task_metrics,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True, type=Path, help="Prediction JSONL.")
    parser.add_argument("--output", required=True, type=Path, help="Metrics JSON.")
    args = parser.parse_args()

    rows = read_jsonl(args.predictions)
    metrics = aggregate(rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
