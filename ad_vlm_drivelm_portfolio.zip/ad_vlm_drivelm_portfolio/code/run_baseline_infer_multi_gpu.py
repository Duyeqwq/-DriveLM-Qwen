#!/usr/bin/env python3
"""Launch baseline inference across free GPUs and merge shard outputs."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def query_gpu_stats() -> list[dict[str, int]]:
    result = subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=index,memory.used,memory.total,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    stats: list[dict[str, int]] = []
    for line in result.stdout.strip().splitlines():
        index, used_mb, total_mb, util = [part.strip() for part in line.split(",")]
        stats.append(
            {
                "index": int(index),
                "used_mb": int(float(used_mb)),
                "total_mb": int(float(total_mb)),
                "util": int(float(util)),
            }
        )
    return stats


def pick_gpus(
    manual_gpus: list[int] | None,
    min_free_mb: int,
    max_used_mb: int,
    max_util: int,
) -> list[int]:
    if manual_gpus:
        return manual_gpus

    selected: list[int] = []
    for gpu in query_gpu_stats():
        free_mb = gpu["total_mb"] - gpu["used_mb"]
        if free_mb >= min_free_mb and gpu["used_mb"] <= max_used_mb and gpu["util"] <= max_util:
            selected.append(gpu["index"])
    return selected


def merge_shards(shard_paths: list[Path], output: Path) -> int:
    output.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    with output.open("w", encoding="utf-8") as out_f:
        for shard_path in shard_paths:
            if not shard_path.exists():
                raise SystemExit(f"Missing shard output: {shard_path}")
            with shard_path.open("r", encoding="utf-8") as in_f:
                for line in in_f:
                    line = line.strip()
                    if not line:
                        continue
                    out_f.write(line + "\n")
                    total += 1
    return total


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-VL-7B-Instruct")
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--max-new-tokens", type=int, default=128)
    parser.add_argument("--dtype", choices=("auto", "bf16", "fp16", "fp32"), default="auto")
    parser.add_argument("--device-map", default="auto")
    parser.add_argument("--adapter-dir", default=None, help="Optional LoRA adapter checkpoint directory.")
    parser.add_argument(
        "--gpus",
        default="",
        help="Comma-separated GPU ids. Empty means auto-pick idle GPUs.",
    )
    parser.add_argument("--min-free-mb", type=int, default=18000, help="Minimum free VRAM to use a GPU.")
    parser.add_argument("--max-used-mb", type=int, default=3000, help="Maximum used VRAM to count GPU as idle.")
    parser.add_argument("--max-util", type=int, default=10, help="Maximum GPU utilization percent for idle pick.")
    parser.add_argument(
        "--keep-shards",
        action="store_true",
        help="Keep per-GPU shard files after merge.",
    )
    args = parser.parse_args()

    manual_gpus = [int(x.strip()) for x in args.gpus.split(",") if x.strip()] if args.gpus else None
    gpus = pick_gpus(manual_gpus, args.min_free_mb, args.max_used_mb, args.max_util)
    if not gpus:
        raise SystemExit(
            "No idle GPU found. Stop other jobs, pass --gpus 0,1,2 manually, "
            "or relax --min-free-mb / --max-used-mb / --max-util."
        )

    script = Path(__file__).with_name("run_baseline_infer.py")
    shard_dir = args.output.parent / f"{args.output.stem}_shards"
    shard_dir.mkdir(parents=True, exist_ok=True)

    print(f"launching {len(gpus)} workers on GPUs: {gpus}")
    processes: list[subprocess.Popen[bytes]] = []
    shard_paths: list[Path] = []
    for shard_id, gpu in enumerate(gpus):
        shard_output = shard_dir / f"gpu{gpu}.jsonl"
        shard_paths.append(shard_output)
        cmd = [
            sys.executable,
            str(script),
            "--model",
            args.model,
            "--input",
            str(args.input),
            "--output",
            str(shard_output),
            "--max-new-tokens",
            str(args.max_new_tokens),
            "--dtype",
            args.dtype,
            "--device-map",
            args.device_map,
            "--gpu",
            str(gpu),
            "--shard-id",
            str(shard_id),
            "--num-shards",
            str(len(gpus)),
        ]
        if args.limit:
            cmd.extend(["--limit", str(args.limit)])
        if args.adapter_dir:
            cmd.extend(["--adapter-dir", args.adapter_dir])
        print(" ".join(cmd))
        processes.append(subprocess.Popen(cmd))

    exit_code = 0
    for proc in processes:
        code = proc.wait()
        if code != 0:
            exit_code = code

    if exit_code != 0:
        raise SystemExit(f"One or more workers failed with exit code {exit_code}")

    merged = merge_shards(shard_paths, args.output)
    print(f"merged {merged} predictions into {args.output}")

    if not args.keep_shards:
        for shard_path in shard_paths:
            shard_path.unlink(missing_ok=True)
        if shard_dir.exists() and not any(shard_dir.iterdir()):
            shard_dir.rmdir()


if __name__ == "__main__":
    main()
