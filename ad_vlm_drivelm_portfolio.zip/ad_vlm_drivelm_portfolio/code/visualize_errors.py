#!/usr/bin/env python3
"""Create a small HTML report for DriveLM/Qwen-VL error analysis."""

from __future__ import annotations

import argparse
import html
import json
import re
from pathlib import Path
from typing import Any


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def normalize(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\w\s\u4e00-\u9fff]", "", text)
    return text


def is_error(row: dict[str, Any]) -> bool:
    answer = normalize(str(row.get("answer", "")))
    prediction = normalize(str(row.get("prediction", "")))
    return bool(answer) and answer != prediction and answer not in prediction


def render_images(images: list[str]) -> str:
    if not images:
        return "<p class='muted'>No image path recorded.</p>"
    tags = []
    for image in images:
        src = Path(image).as_uri() if Path(image).is_absolute() else html.escape(image)
        tags.append(f"<img src='{src}' alt='{html.escape(image)}'>")
    return "\n".join(tags)


def render_report(rows: list[dict[str, Any]], title: str) -> str:
    cards = []
    for row in rows:
        metadata = row.get("metadata", {})
        task = metadata.get("task") or "unknown"
        cards.append(
            f"""
            <section class="card">
              <div class="meta">id: {html.escape(str(row.get("id", "")))} | task: {html.escape(str(task))}</div>
              <div class="images">{render_images([str(x) for x in row.get("images", [])])}</div>
              <h3>Question</h3>
              <p>{html.escape(str(row.get("question", "")))}</p>
              <h3>Ground Truth</h3>
              <p>{html.escape(str(row.get("answer", "")))}</p>
              <h3>Prediction</h3>
              <p>{html.escape(str(row.get("prediction", "")))}</p>
            </section>
            """
        )

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>{html.escape(title)}</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 24px; background: #f6f7f9; color: #1f2933; }}
    h1 {{ margin-bottom: 4px; }}
    .summary {{ color: #52616b; margin-bottom: 24px; }}
    .card {{ background: white; border: 1px solid #d9e2ec; border-radius: 10px; padding: 16px; margin: 16px 0; }}
    .meta {{ color: #627d98; font-size: 13px; margin-bottom: 12px; }}
    .images {{ display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 12px; }}
    img {{ max-width: 360px; max-height: 260px; border-radius: 6px; border: 1px solid #d9e2ec; object-fit: contain; }}
    h3 {{ margin: 12px 0 4px; font-size: 15px; }}
    p {{ margin: 0 0 8px; line-height: 1.5; }}
    .muted {{ color: #829ab1; }}
  </style>
</head>
<body>
  <h1>{html.escape(title)}</h1>
  <p class="summary">Showing {len(rows)} likely error samples. Use this report to tag night, occlusion, complex junction, planning, and behavior-reasoning failures.</p>
  {''.join(cards)}
</body>
</html>
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True, type=Path, help="Prediction JSONL.")
    parser.add_argument("--output", required=True, type=Path, help="Output HTML path.")
    parser.add_argument("--max-samples", type=int, default=100)
    args = parser.parse_args()

    rows = read_jsonl(args.predictions)
    errors = [row for row in rows if is_error(row)][: args.max_samples]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(render_report(errors, "DriveLM + Qwen-VL Error Report"), encoding="utf-8")
    print(f"saved {len(errors)} error samples to {args.output}")


if __name__ == "__main__":
    main()
