#!/usr/bin/env python3
"""Convert DriveLM-style QA data into Qwen-VL SFT JSONL."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Iterable


QUESTION_KEYS = ("question", "query", "prompt", "q")
ANSWER_KEYS = ("answer", "gt_answer", "ground_truth", "label", "a")
IMAGE_KEY_HINTS = ("image", "img", "camera", "cam", "filename", "file_name", "path")
ID_KEYS = ("id", "sample_id", "sample_token", "token", "scene_token", "question_id")
TASK_KEYS = ("task", "category", "type", "qa_type", "tag")
CAMERA_ORDER = (
    "CAM_FRONT",
    "CAM_FRONT_LEFT",
    "CAM_FRONT_RIGHT",
    "CAM_BACK",
    "CAM_BACK_LEFT",
    "CAM_BACK_RIGHT",
)


def load_json(path: Path) -> Any:
    if not path.exists():
        raise SystemExit(
            f"Input json not found: {path}\n"
            "Please put the DriveLM QA json under data/drivelm/ first, "
            "or pass the real path with --input."
        )
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_records(obj: Any) -> list[dict[str, Any]]:
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]
    if not isinstance(obj, dict):
        return []

    for key in ("data", "samples", "annotations", "questions", "qa", "qas", "infos", "train", "val", "test"):
        value = obj.get(key)
        if isinstance(value, list):
            return [x for x in value if isinstance(x, dict)]

    if all(isinstance(value, dict) for value in obj.values()):
        return list(obj.values())

    return [obj]


def key_matches(key: str, candidates: Iterable[str]) -> bool:
    lowered = key.lower()
    return any(lowered == candidate.lower() for candidate in candidates)


def find_value(obj: Any, candidates: Iterable[str]) -> Any | None:
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key_matches(key, candidates):
                return value
        for value in obj.values():
            found = find_value(value, candidates)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = find_value(value, candidates)
            if found is not None:
                return found
    return None


def to_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    return json.dumps(value, ensure_ascii=False)


def is_image_like(key: str, value: Any) -> bool:
    if not isinstance(value, str):
        return False
    lowered_key = key.lower()
    lowered_value = value.lower()
    return any(hint in lowered_key for hint in IMAGE_KEY_HINTS) or lowered_value.endswith(
        (".jpg", ".jpeg", ".png", ".webp")
    )


def collect_images(obj: Any, image_root: Path | None) -> list[str]:
    images: list[str] = []

    def walk(value: Any, key: str = "") -> None:
        if isinstance(value, dict):
            for child_key, child_value in value.items():
                walk(child_value, child_key)
        elif isinstance(value, list):
            for child_value in value:
                walk(child_value, key)
        elif is_image_like(key, value):
            path = Path(value)
            if image_root is not None and not path.is_absolute():
                path = image_root / path
            images.append(str(path))

    walk(obj)
    seen: set[str] = set()
    unique_images: list[str] = []
    for image in images:
        if image not in seen:
            unique_images.append(image)
            seen.add(image)
    return unique_images


def collect_frame_images(image_paths: Any, image_root: Path | None) -> list[str]:
    if not isinstance(image_paths, dict):
        return collect_images(image_paths, image_root)

    ordered_values: list[Any] = []
    for camera in CAMERA_ORDER:
        if camera in image_paths:
            ordered_values.append(image_paths[camera])
    for camera, value in image_paths.items():
        if camera not in CAMERA_ORDER:
            ordered_values.append(value)

    images: list[str] = []
    for value in ordered_values:
        if isinstance(value, str):
            path = Path(value)
            if image_root is not None and not path.is_absolute():
                path = (image_root / path).resolve(strict=False)
            images.append(str(path))
    return images


def has_qa(obj: dict[str, Any]) -> bool:
    return find_value(obj, QUESTION_KEYS) is not None and find_value(obj, ANSWER_KEYS) is not None


def has_direct_qa(obj: dict[str, Any]) -> bool:
    return any(key_matches(key, QUESTION_KEYS) for key in obj) and any(key_matches(key, ANSWER_KEYS) for key in obj)


def iter_drivelm_frame_qa_records(record: dict[str, Any], scene_index: int) -> Iterable[dict[str, Any]]:
    key_frames = record.get("key_frames")
    if not isinstance(key_frames, dict):
        return

    scene_description = record.get("scene_description", "")
    for frame_token, frame in key_frames.items():
        if not isinstance(frame, dict):
            continue
        qa_by_task = frame.get("QA", {})
        if not isinstance(qa_by_task, dict):
            continue
        images = collect_frame_images(frame.get("image_paths", {}), None)
        for task, qa_items in qa_by_task.items():
            if not isinstance(qa_items, list):
                continue
            for qa_index, qa in enumerate(qa_items):
                if not isinstance(qa, dict):
                    continue
                question = to_text(qa.get("Q") or qa.get("question"))
                answer = to_text(qa.get("A") or qa.get("answer"))
                if not question or not answer:
                    continue
                yield {
                    "id": f"scene{scene_index:04d}_{frame_token}_{task}_{qa_index:04d}",
                    "question": question,
                    "answer": answer,
                    "task": str(task),
                    "scene_description": scene_description,
                    "frame_token": frame_token,
                    "images": images,
                }


def iter_qa_records(record: dict[str, Any], scene_index: int = 0) -> Iterable[dict[str, Any]]:
    yielded = False
    for qa_record in iter_drivelm_frame_qa_records(record, scene_index):
        yielded = True
        yield qa_record
    if yielded:
        return

    if has_direct_qa(record):
        yield record
        return

    def walk(value: Any, parent: dict[str, Any]) -> Iterable[dict[str, Any]]:
        if isinstance(value, dict):
            if has_direct_qa(value):
                merged = {**parent, **value}
                yield merged
                return
            for child_value in value.values():
                yield from walk(child_value, parent)
        elif isinstance(value, list):
            for child_value in value:
                yield from walk(child_value, parent)

    yield from walk(record, record)


def build_qwen_sample(record: dict[str, Any], index: int, image_root: Path | None, max_images: int) -> dict[str, Any] | None:
    question = to_text(find_value(record, QUESTION_KEYS))
    answer = to_text(find_value(record, ANSWER_KEYS))
    if not question or not answer:
        return None

    raw_images = record.get("images")
    if isinstance(raw_images, list):
        images = []
        for image in raw_images:
            path = Path(str(image))
            if image_root is not None and not path.is_absolute():
                path = (image_root / path).resolve(strict=False)
            images.append(str(path))
    else:
        images = collect_images(record, image_root)
    if max_images > 0:
        images = images[:max_images]

    content: list[dict[str, str]] = [{"type": "image", "image": image} for image in images]
    content.append({"type": "text", "text": question})

    sample_id = to_text(find_value(record, ID_KEYS)) or f"sample_{index:08d}"
    task = to_text(find_value(record, TASK_KEYS))
    return {
        "id": sample_id,
        "messages": [
            {"role": "user", "content": content},
            {"role": "assistant", "content": [{"type": "text", "text": answer}]},
        ],
        "metadata": {
            "task": task,
            "num_images": len(images),
            "frame_token": record.get("frame_token", ""),
            "scene_description": record.get("scene_description", ""),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path, help="DriveLM json path.")
    parser.add_argument("--output", required=True, type=Path, help="Output JSONL path.")
    parser.add_argument("--image-root", type=Path, default=None, help="Optional image root prefix.")
    parser.add_argument("--max-images", type=int, default=1, help="Use 1 for single-frame, 0 for all images.")
    parser.add_argument("--limit", type=int, default=0, help="Optional max converted samples.")
    args = parser.parse_args()

    raw = load_json(args.input)
    records = load_records(raw)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    converted = 0
    skipped = 0
    with args.output.open("w", encoding="utf-8") as f:
        for scene_index, record in enumerate(records):
            for qa_record in iter_qa_records(record, scene_index):
                sample = build_qwen_sample(qa_record, converted, args.image_root, args.max_images)
                if sample is None:
                    skipped += 1
                    continue
                f.write(json.dumps(sample, ensure_ascii=False) + "\n")
                converted += 1
                if args.limit and converted >= args.limit:
                    break
            if args.limit and converted >= args.limit:
                break

    print(f"input records: {len(records)}")
    print(f"converted samples: {converted}")
    print(f"skipped qa records: {skipped}")
    print(f"output: {args.output}")


if __name__ == "__main__":
    main()
