#!/bin/bash
set -euo pipefail

# LoRA full train on scene-split train set, 3 GPUs.
cd /mnt/work/dsg/ad-vlm-project/Qwen-VL/qwen-vl-finetune

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2}"
export NPROC_PER_NODE="${NPROC_PER_NODE:-3}"
export MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
export MASTER_PORT="${MASTER_PORT:-$(shuf -i 20001-29999 -n 1)}"

export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

deepspeed=./scripts/zero2.json
llm=Qwen/Qwen2.5-VL-7B-Instruct
datasets=drivelm_train
run_name=drivelm_lora_full
output_dir=/mnt/work/dsg/ad-vlm-project/experiments/qwen_lora_single_frame/full_train
log_dir=${output_dir}/torchrun_logs
mkdir -p "${log_dir}"

args="
  --deepspeed ${deepspeed}
  --model_name_or_path ${llm}
  --dataset_use ${datasets}
  --data_flatten False
  --tune_mm_vision False
  --tune_mm_mlp True
  --tune_mm_llm True
  --bf16
  --lora_enable True
  --lora_r 64
  --lora_alpha 128
  --output_dir ${output_dir}
  --num_train_epochs 1
  --per_device_train_batch_size 1
  --gradient_accumulation_steps 16
  --max_pixels 28000
  --min_pixels 784
  --eval_strategy no
  --save_strategy steps
  --save_steps 500
  --save_total_limit 4
  --learning_rate 1e-4
  --weight_decay 0
  --warmup_ratio 0.03
  --max_grad_norm 1
  --lr_scheduler_type cosine
  --logging_steps 50
  --model_max_length 2048
  --gradient_checkpointing True
  --dataloader_num_workers 4
  --run_name ${run_name}
  --report_to none"

torchrun --nproc_per_node=${NPROC_PER_NODE} \
  --master_addr=${MASTER_ADDR} \
  --master_port=${MASTER_PORT} \
  --log-dir="${log_dir}" \
  --tee=3 \
  qwenvl/train/train_qwen.py ${args}
