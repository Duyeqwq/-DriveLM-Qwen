#!/usr/bin/env python3
"""Run baseline inference with Qwen2.5-VL on Qwen-style SFT JSONL."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def extract_text(sample: dict[str, Any], role: str) -> str:
    for message in sample.get("messages", []):
        if message.get("role") != role:
            continue
        content = message.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            texts = [item.get("text", "") for item in content if isinstance(item, dict) and item.get("type") == "text"]
            return "\n".join(text for text in texts if text)
    return ""


def extract_images(sample: dict[str, Any]) -> list[str]:
    images: list[str] = []
    for message in sample.get("messages", []):
        content = message.get("content", [])
        if isinstance(content, list):
            for item in content:
                if isinstance(item, dict) and item.get("type") == "image" and item.get("image"):
                    images.append(str(item["image"]))
    return images


def _from_pretrained_local_first(loader, model_name: str, **kwargs):
    try:
        return loader.from_pretrained(model_name, local_files_only=True, **kwargs)
    except (OSError, ValueError):
        print(f"local cache miss for {model_name}, trying Hugging Face hub...")
        return loader.from_pretrained(model_name, local_files_only=False, **kwargs)


def load_model(model_name: str, dtype: str, device_map: str, adapter_dir: str | None = None):
    try:
        import torch
        from qwen_vl_utils import process_vision_info
        from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration
    except ImportError as exc:
        raise SystemExit(
            "Missing runtime dependency. Install transformers, qwen-vl-utils, torch, accelerate, and pillow first."
        ) from exc

    torch_dtype = {
        "auto": "auto",
        "bf16": torch.bfloat16,
        "fp16": torch.float16,
        "fp32": torch.float32,
    }[dtype]
    model = _from_pretrained_local_first(
        Qwen2_5_VLForConditionalGeneration,
        model_name,
        torch_dtype=torch_dtype,
        device_map=device_map,
    )
    processor_source = model_name
    if adapter_dir:
        from peft import PeftModel

        model = PeftModel.from_pretrained(model, adapter_dir, local_files_only=True)
        processor_source = adapter_dir
    processor = _from_pretrained_local_first(AutoProcessor, processor_source)
    return model, processor, process_vision_info


def select_shard(rows: list[dict[str, Any]], shard_id: int, num_shards: int) -> list[dict[str, Any]]:
    if num_shards <= 1:
        return rows
    return [row for idx, row in enumerate(rows) if idx % num_shards == shard_id]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-VL-7B-Instruct", help="HF model name or local path.")
    parser.add_argument("--input", required=True, type=Path, help="Qwen SFT JSONL.")
    parser.add_argument("--output", required=True, type=Path, help="Prediction JSONL.")
    parser.add_argument("--limit", type=int, default=0, help="Optional max samples.")
    parser.add_argument("--max-new-tokens", type=int, default=128)
    parser.add_argument("--dtype", choices=("auto", "bf16", "fp16", "fp32"), default="auto")
    parser.add_argument("--device-map", default="auto")
    parser.add_argument("--adapter-dir", default=None, help="Optional LoRA adapter checkpoint directory.")
    parser.add_argument("--gpu", type=int, default=None, help="Pin this worker to one GPU index.")
    parser.add_argument("--shard-id", type=int, default=0, help="Shard index for multi-GPU inference.")
    parser.add_argument("--num-shards", type=int, default=1, help="Total shard count for multi-GPU inference.")
    args = parser.parse_args()

    if args.gpu is not None:
        os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    if args.shard_id < 0 or args.num_shards < 1 or args.shard_id >= args.num_shards:
        raise SystemExit(f"Invalid shard config: shard-id={args.shard_id}, num-shards={args.num_shards}")

    rows = read_jsonl(args.input)
    if args.limit:
        rows = rows[: args.limit]
    rows = select_shard(rows, args.shard_id, args.num_shards)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    if args.num_shards > 1:
        gpu_info = f"gpu={args.gpu}" if args.gpu is not None else "gpu=auto"
        print(f"worker shard {args.shard_id + 1}/{args.num_shards} ({gpu_info}), samples={len(rows)}")

    model, processor, process_vision_info = load_model(
        args.model, args.dtype, args.device_map, adapter_dir=args.adapter_dir
    )
    device = next(model.parameters()).device

    with args.output.open("w", encoding="utf-8") as f:
        for idx, sample in enumerate(rows):
            messages = [message for message in sample.get("messages", []) if message.get("role") == "user"]
            text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            image_inputs, video_inputs = process_vision_info(messages)
            inputs = processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt",
            ).to(device)

            generated_ids = model.generate(**inputs, max_new_tokens=args.max_new_tokens)
            generated_ids_trimmed = [
                out_ids[len(in_ids) :] for in_ids, out_ids in zip(inputs.input_ids, generated_ids, strict=False)
            ]
            prediction = processor.batch_decode(
                generated_ids_trimmed,
                skip_special_tokens=True,
                clean_up_tokenization_spaces=False,
            )[0].strip()

            row = {
                "id": sample.get("id", f"sample_{idx:08d}"),
                "question": extract_text(sample, "user"),
                "answer": extract_text(sample, "assistant"),
                "prediction": prediction,
                "images": extract_images(sample),
                "metadata": sample.get("metadata", {}),
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            print(f"[{idx + 1}/{len(rows)}] {row['id']}: {prediction[:120]}")

    print(f"saved predictions to {args.output}")


if __name__ == "__main__":
    main()
