#!/usr/bin/env python3
"""Convert project Qwen SFT JSONL into Qwen-VL finetune format."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def extract_parts(sample: dict[str, Any]) -> tuple[list[str], str, str]:
    images: list[str] = []
    question = ""
    answer = ""
    for message in sample.get("messages", []):
        role = message.get("role")
        content = message.get("content", [])
        if role == "user" and isinstance(content, list):
            texts: list[str] = []
            for item in content:
                if not isinstance(item, dict):
                    continue
                if item.get("type") == "image" and item.get("image"):
                    images.append(str(item["image"]))
                elif item.get("type") == "text" and item.get("text"):
                    texts.append(str(item["text"]))
            question = "\n".join(texts)
        elif role == "assistant":
            if isinstance(content, str):
                answer = content
            elif isinstance(content, list):
                answer = "\n".join(
                    str(item.get("text", ""))
                    for item in content
                    if isinstance(item, dict) and item.get("type") == "text"
                )
    return images, question.strip(), answer.strip()


def to_finetune_sample(sample: dict[str, Any]) -> dict[str, Any] | None:
    images, question, answer = extract_parts(sample)
    if not images or not question or not answer:
        return None
    image_tags = "\n".join("<image>" for _ in images)
    return {
        "image": images[0] if len(images) == 1 else images,
        "conversations": [
            {"from": "human", "value": f"{image_tags}\n{question}"},
            {"from": "gpt", "value": answer},
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()

    converted = 0
    skipped = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.input.open("r", encoding="utf-8") as src, args.output.open("w", encoding="utf-8") as dst:
        for line in src:
            line = line.strip()
            if not line:
                continue
            sample = to_finetune_sample(json.loads(line))
            if sample is None:
                skipped += 1
                continue
            dst.write(json.dumps(sample, ensure_ascii=False) + "\n")
            converted += 1
            if args.limit and converted >= args.limit:
                break

    print(f"converted: {converted}")
    print(f"skipped: {skipped}")
    print(f"output: {args.output}")


if __name__ == "__main__":
    main()
