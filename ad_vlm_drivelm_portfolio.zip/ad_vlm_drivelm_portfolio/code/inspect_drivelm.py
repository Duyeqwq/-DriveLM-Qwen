#!/usr/bin/env python3
"""Inspect DriveLM-style QA json files before conversion."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any


COMMON_RECORD_KEYS = (
    "data",
    "samples",
    "annotations",
    "questions",
    "qa",
    "qas",
    "infos",
    "train",
    "val",
    "test",
)

IMAGE_KEY_HINTS = ("image", "img", "camera", "cam", "filename", "file_name", "path")


def load_json(path: Path) -> Any:
    if not path.exists():
        raise SystemExit(
            f"Input json not found: {path}\n"
            "Please put the DriveLM QA json under data/drivelm/ first, "
            "or pass the real path with --input."
        )
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def unwrap_records(obj: Any) -> list[dict[str, Any]]:
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]

    if not isinstance(obj, dict):
        raise TypeError(f"Expected dict or list json root, got {type(obj).__name__}")

    for key in COMMON_RECORD_KEYS:
        value = obj.get(key)
        if isinstance(value, list):
            return [x for x in value if isinstance(x, dict)]

    for value in obj.values():
        if isinstance(value, list) and value and isinstance(value[0], dict):
            return [x for x in value if isinstance(x, dict)]

    if all(isinstance(value, dict) for value in obj.values()):
        return list(obj.values())

    return [obj]


def walk_paths(obj: Any, prefix: str = "") -> list[tuple[str, Any]]:
    if isinstance(obj, dict):
        out: list[tuple[str, Any]] = []
        for key, value in obj.items():
            next_prefix = f"{prefix}.{key}" if prefix else str(key)
            out.extend(walk_paths(value, next_prefix))
        return out
    if isinstance(obj, list):
        if not obj:
            return [(prefix, "[]")]
        return walk_paths(obj[0], f"{prefix}[]")
    return [(prefix, obj)]


def maybe_image_path(key: str, value: Any) -> bool:
    if not isinstance(value, str):
        return False
    lowered_key = key.lower()
    lowered_value = value.lower()
    if any(hint in lowered_key for hint in IMAGE_KEY_HINTS):
        return True
    return lowered_value.endswith((".jpg", ".jpeg", ".png", ".webp"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path, help="DriveLM json path.")
    parser.add_argument("--image-root", type=Path, default=None, help="Optional image root.")
    parser.add_argument("--limit", type=int, default=3, help="Number of examples to print.")
    args = parser.parse_args()

    raw = load_json(args.input)
    records = unwrap_records(raw)
    key_counter: Counter[str] = Counter()
    leaf_counter: Counter[str] = Counter()
    image_refs: Counter[str] = Counter()
    existing_images = 0

    for record in records:
        key_counter.update(record.keys())
        for path, value in walk_paths(record):
            leaf_counter[path] += 1
            if maybe_image_path(path, value):
                image_refs[str(value)] += 1
                if args.image_root is not None and (args.image_root / str(value)).exists():
                    existing_images += 1

    print(f"input: {args.input}")
    print(f"records: {len(records)}")
    print("\ntop-level keys:")
    for key, count in key_counter.most_common():
        print(f"  {key}: {count}")

    print("\ncommon leaf paths:")
    for key, count in leaf_counter.most_common(50):
        print(f"  {key}: {count}")

    print("\nimage-like references:")
    for image, count in image_refs.most_common(20):
        print(f"  {image}: {count}")
    if args.image_root is not None:
        print(f"existing image refs under --image-root: {existing_images}/{sum(image_refs.values())}")

    print("\nexamples:")
    for idx, record in enumerate(records[: args.limit]):
        print(f"\n--- example {idx} ---")
        print(json.dumps(record, ensure_ascii=False, indent=2)[:4000])


if __name__ == "__main__":
    main()
